<?php

require('Net/EPP/AT/Client.php');
require('epp-include.php');

$domain ='lecker-schnittchen.de';

$param[] = array('domain' => $domain,                  
                 'trid'  => $c->user->trid);

$epp_return = $epp->command('domain-info', $param);
unset($param);

echo $epp_return->request ."\n";
echo $epp_return->code ."\n";
echo $epp_return->msg ."\n";
echo $epp_return->xml ."\n";

if ($epp_return->error) {
  echo "Errors: \n"; 
  print_r($epp_return->error);
}

$epp->disconnect();
?>
