<?php
if ($argv[1]) {
  $config = $argv[1];}
else {
  $config = 'epp-conf.xml';
}

$c = simplexml_load_file($config);

printf("Path %s\n", $c->settings->path);


$host = $c->server->host;
$port = (int)  $c->server->port;
$timeout = (int) $c->server->timeout;
$ssl = (boolean) $c->server->ssl;

global $epp, $frame, $debug;

$debug = 0;
if ($debug == 1) {print_r($c);}

$epp = new Net_EPP_AT_Client();
$epp->TemplateDir = $c->settings->templates; // 'templates/de';
$epp->protocol = 'rri';

$greeting = $epp->connect($host, $port, $timeout, $ssl);

print_r($greeting);
// login you will need this everytime
$param[] = array('login' => $c->user->login,
                 'pw'   => $c->user->pw,
                 'trid'  => $c->user->trid);

$epp_return = $epp->command('login', $param);
unset($param);

if ($debug == 4) {
echo $epp_return->request ."\n";
echo $epp_return->code ."\n";
echo $epp_return->msg ."\n";
echo $epp_return->xml ."\n";
}
?>
