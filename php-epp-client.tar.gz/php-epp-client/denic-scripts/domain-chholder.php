<?php

require('Net/EPP/AT/Client.php');
require('epp-include.php');

$domain ='lecker-schnittchen.de';

$paramc[] = array(
'domain'     => $domain,                  
'host1'      => 'docks08.rzone.de',
'host2'      => 'shades12.rzone.de',
'registrant' => 'DENIC-340-MHTEST1',
'admin'      => 'DENIC-340-MHTEST',
'zone'       => 'DENIC-340-MHTEST',                  
'tech'       => 'DENIC-340-MHTEST',
'trid'  => time(),
);

$epp_return = $epp->command('domain-chholder', $paramc);
unset($param);

echo $epp_return->request ."\n";
echo $epp_return->code ."\n";
echo $epp_return->msg ."\n";
echo $epp_return->xml ."\n";

if ($epp_return->error) {
  echo "Errors: \n"; 
  print_r($epp_return->error);
}

$epp->disconnect();

 

?>
